package com.example.tumamobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
