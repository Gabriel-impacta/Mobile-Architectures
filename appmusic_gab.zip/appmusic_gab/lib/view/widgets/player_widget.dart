

import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tumamobile/view_model/media_view_model.dart';

import '../../model/media.dart';

enum PlayerState { stopped, playing, paused }
enum PlayingRouteState { speakers, earpiece }

class PlayerWidget extends StatefulWidget {
  final PlayerMode mode;
  final Function function;

  PlayerWidget({Key? key, required this.function,
    this.mode = PlayerMode.MEDIA_PLAYER }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _PlayerWidgetState(mode);
  }

}

class _PlayerWidgetState extends State<PlayerWidget> {
  String? _prevSongName;
  PlayerMode mode;

  late AudioPlayer _audioPlayer;
  Duration? _duration;
  Duration? _position;

  PlayerState _playerState = PlayerState.stopped;
  StreamSubscription? _durationSubscription;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _playerCompleteSubscription;
  StreamSubscription? _playerErrorSubscription;
  StreamSubscription? _playerStateSubscription;

  get _isPlaying => _playerState == PlayerState.playing;

  _PlayerWidgetState(this.mode);

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _durationSubscription?.cancel();
    _positionSubscription?.cancel();
    _playerCompleteSubscription?.cancel();
    _playerErrorSubscription?.cancel();
    _playerStateSubscription?.cancel();
    super.dispose();
  }

  void _playCurrentMedia(Media? media) {
    if (media != null && _prevSongName != media.trackName) {
      _prevSongName = media.trackName;
      _position = null;
      _stop();
      _play(media);
    }
  }

  @override
  Widget build(BuildContext context) {
    Media? media = Provider.of<MediaViewModel>(context).media;
    _playCurrentMedia(media);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // IconButton(
            //     onPressed: () => null,
            //     icon: Icon(
            //       Icons.fast_rewind,
            //       size: 25.0,
            //       color: Theme.of(context).brightness == Brightness.dark
            //         ? Theme.of(context).accentColor
            //           : Color(0xFF787878),
            //     )
            // ),
            ClipOval(
              child: Container(
                color: Theme.of(context).accentColor.withAlpha(30),
                width: 50.0,
                height: 50.0,
                child: IconButton(
                  onPressed: () {
                    if(_isPlaying) {
                      widget.function();
                      _pause();
                    } else {
                      if (media != null) {
                        widget.function();
                        _play(media);
                      }
                    }
                  },
                  icon: Icon(
                    _isPlaying ? Icons.pause : Icons.play_arrow,
                    size: 30.0,
                    color: Theme.of(context).accentColor,
                  ),
                ),
              ),
            ),
            // IconButton(
            //     onPressed: () => null,
            //     icon: Icon(
            //       Icons.fast_forward,
            //       size: 25.0,
            //       color: Theme.of(context).brightness == Brightness.dark
            //           ? Theme.of(context).accentColor
            //           : Color(0xFF787878),
            //     )
            // ),
          ],
        ),
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 12.0, right: 12.0),
              child: Stack(
                children: [
                  Slider(
                    onChanged: (v) {
                      final position = v * _duration!.inMilliseconds;
                      _audioPlayer.seek(Duration(milliseconds: position.round()));
                    },
                    value: (_position != null &&
                            _duration != null &&
                            _position!.inMilliseconds > 0 &&
                            _position!.inMilliseconds < _duration!.inMilliseconds)
                      ? _position!.inMilliseconds / _duration!.inMilliseconds
                      : 0.0,
                  )
                ],
              ),
            )
          ],
        )
      ],
    );
  }

  void _initAudioPlayer() {
    _audioPlayer = AudioPlayer(mode: mode);

    _durationSubscription = _audioPlayer.onDurationChanged.listen((duration) {
      setState(() => _duration = duration);

      if(Theme.of(context).platform == TargetPlatform.iOS) {
        _audioPlayer.startHeadlessService();

        _audioPlayer.setNotification(
          title: 'App Name',
          artist: 'Artist',
          albumTitle: 'Name',
          imageUrl: 'Url',
          forwardSkipInterval: const Duration(seconds: 30),
          backwardSkipInterval: const Duration(seconds: 30),
          duration: duration,
          elapsedTime: Duration(seconds: 0));
      }
    });

    _positionSubscription = _audioPlayer.onAudioPositionChanged.listen((event) => setState(() {
        _position = event;
      }));

    _playerCompleteSubscription = _audioPlayer.onPlayerCompletion.listen((event) {
      _onComplete();
      setState(() {
        _position = _duration;
      });
    });

    _playerErrorSubscription = _audioPlayer.onPlayerError.listen((event) {
      print('audio player error: $event');
      setState(() {
        _playerState = PlayerState.stopped;
        _duration = Duration(seconds: 0);
        _position = Duration(seconds: 0);
      });
    });
  }

  Future<int> _play(Media media) async {
    final playPosition = (_position != null &&
          _duration != null &&
          _position!.inMilliseconds > 0 &&
          _position!.inMilliseconds < _duration!.inMilliseconds)
        ? _position
        : null;

    final result =
        await _audioPlayer.play(media.previewUrl!, position: playPosition);

    if (result == 1) setState(() => _playerState = PlayerState.playing);

    _audioPlayer.setPlaybackRate(playbackRate: 1.0);

    return result;
  }

  Future<int> _pause() async {
    final result = await _audioPlayer.pause();
    if(result == 1) setState(() => _playerState = PlayerState.paused);
    return result;
  }

  Future<int> _stop() async {
    final result = await _audioPlayer.stop();
    if(result == 1) {
      setState(() {
        _playerState = PlayerState.stopped;
        _position = Duration();
      });
    }
    return result;
  }

  void _onComplete() {
    setState(() {
      _playerState = PlayerState.stopped;
    });
  }
}